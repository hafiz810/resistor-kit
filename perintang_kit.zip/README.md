
# Basic of Resistor Kit

This project provides an educational tool to understand resistors, including:

- Introduction to resistors and their types
- Color code chart for resistors
- Resistor color code calculator

## How to use
1. Upload the files to your GitHub repository.
2. Enable GitHub Pages to host the website.
3. Access the website through the provided URL.
